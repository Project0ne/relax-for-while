const LoggerKey = 'relax4while_logger_key'
const STORAGE_KEY = 'relax4while_settings'
const ALARM_KEY = 'relax4while_alarm'

//register listener
chrome?.alarms?.onAlarm?.addListener(relax4while)

// Listen for direct trigger from popup when countdown finishes
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'fireDisplay') {
        console.log('[relax4while] Direct trigger from popup')
        relax4while()
        sendResponse({ ok: true })
    }
    return true
})

function thisPageAllowExecute(url) {
    const whiteList = ['https:', 'http:']
    let allow = false
    for (let i = 0; i < whiteList.length; i++) {
        if (url.startsWith(whiteList[i])) { allow = true; break }
    }

    return allow
}

async function checkAlarmState() {
    try {
        //get config
        const value = await chrome.storage.local.get([STORAGE_KEY])
        let settings = {}
        if (value && value[STORAGE_KEY]) { settings = JSON.parse(value[STORAGE_KEY]) }

        //query older alarm info
        const alarmCreateInfo = await chrome.alarms.get(ALARM_KEY)

        //state is off, clear alarm info
        if (!settings.state && alarmCreateInfo) {
            await chrome.alarms.clear(ALARM_KEY)
            return false
        }

        //create new alarm info if state is on.
        if (settings.state && !alarmCreateInfo) {
            await chrome.alarms.create(ALARM_KEY, { periodInMinutes: settings.interval })
        }

        //clear and create alarm info cause settings changed.
        if (settings.state && alarmCreateInfo && alarmCreateInfo.periodInMinutes !== settings.interval) {
            //clear older
            await chrome.alarms.clear(ALARM_KEY)
            //create new
            await chrome.alarms.create(ALARM_KEY, { periodInMinutes: settings.interval })
        }
        // console.log('[relax4while] checkAlarmState successfully.')
    } catch (err) { console.log('[relax4while] checkAlarmState failed: ', err) }
}

checkAlarmState()

// Listen for settings changes from popup and re-evaluate alarm state
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[STORAGE_KEY]) {
        checkAlarmState()
    }
    if (area === 'local' && changes['relax4while_badge']) {
        updateBadgeTicker()
    }
})

// ====== Badge Countdown on Extension Icon ======
const BADGE_KEY = 'relax4while_badge'
let badgeInterval = null

async function updateBadgeTicker() {
    try {
        const result = await chrome.storage.local.get([BADGE_KEY])
        if (!result || !result[BADGE_KEY]) { clearBadge(); return }
        const badge = JSON.parse(result[BADGE_KEY])

        if (badgeInterval) { clearInterval(badgeInterval); badgeInterval = null }

        if (badge.paused && badge.remaining > 0) {
            // Show static paused time
            setBadgeText(formatBadge(badge.remaining))
            chrome.action.setBadgeBackgroundColor({ color: '#f0a030' })
            return
        }
        if (!badge.endTime || badge.endTime <= 0) { clearBadge(); return }

        chrome.action.setBadgeBackgroundColor({ color: '#E74C3C' })
        tickBadge(badge.endTime)
        badgeInterval = setInterval(() => tickBadge(badge.endTime), 1000)
    } catch (e) { console.log('[bg] badge error:', e) }
}

function tickBadge(endTime) {
    const remaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1000))
    if (remaining <= 0) {
        clearBadge()
        if (badgeInterval) { clearInterval(badgeInterval); badgeInterval = null }
        return
    }
    setBadgeText(formatBadge(remaining))
}

function formatBadge(sec) {
    const m = Math.floor(sec / 60)
    const s = sec % 60
    if (m > 0) return `${m}m`
    return `${s}s`
}

function setBadgeText(text) {
    chrome.action.setBadgeText({ text })
}

function clearBadge() {
    chrome.action.setBadgeText({ text: '' })
}

// Init badge on startup
updateBadgeTicker()

//doc https://developer.chrome.com/docs/extensions/reference/api/tabs?hl=zh-cn
async function getCurrentTab() {
    let queryOpts = { active: true, lastFocusedWindow: true }
    let [tab] = await chrome.tabs.query(queryOpts)

    return tab
}

async function relax4while() {
    // console.log('[relax4while] onAlarm hit...')
    try {
        //get config
        const value = await chrome.storage.local.get([STORAGE_KEY])
        let settings = {}, tabInfo = await getCurrentTab()
        if (!tabInfo) { console.log('[relax4while] can not get current tab info'); return false }
        console.log(`[relax4while] current tab info: [${tabInfo.title}](${tabInfo.url})`)
        if (!thisPageAllowExecute(tabInfo.url)) { console.log('[relax4while] this page not allow execute') }
        if (value && value[STORAGE_KEY]) { settings = JSON.parse(value[STORAGE_KEY]) }

        //perform action 
        //clear old
        await chrome.scripting.removeCSS({
            files: ['./assets/css/relax4while_--tips-all.css'],
            target: { tabId: tabInfo.id, allFrames: false },
            origin: 'USER'
        })
        await chrome.scripting.insertCSS({
            files: ['./assets/css/relax4while_--tips-all.css'],
            target: { tabId: tabInfo.id, allFrames: false },
            origin: 'USER'
        })
        //doc https://developer.chrome.com/docs/extensions/reference/api/scripting?hl=zh-cn
        await chrome.scripting.executeScript({
            target: { tabId: tabInfo.id, allFrames: false },
            func: inlineFunc,
            args: [settings]
        })
        // console.log('[relax4while] relax4while function injected successfully')
    } catch (err) { console.log('[relax4while] relax4while function execute failed: ', err) }
}

async function inlineFunc(settings) {
    // console.log('[relax4while] fire inlineFunc function...')

    const logoSvg128 = `<svg t="1709112045300" class="relax4while_--icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1501" xmlns:xlink="http://www.w3.org/1999/xlink" width="128" height="128"><path d="M504.526848 95.7952C465.666048 95.7952 434.024448 127.488 434.024448 166.2976c0 38.912 31.6416 70.5024 70.5024 70.5024s70.5024-31.6416 70.5024-70.5024S543.387648 95.7952 504.526848 95.7952m0 185.6A115.2 115.2 0 0 1 389.378048 166.2976 115.3024 115.3024 0 0 1 504.526848 51.2a115.3024 115.3024 0 0 1 115.1488 115.2 115.2 115.2 0 0 1-115.1488 115.0464" fill="#e6e6e6" p-id="1502"></path><path d="M884.277248 787.8144a22.1184 22.1184 0 0 1-9.5232-2.1504L678.965248 665.2416a22.4256 22.4256 0 0 1-10.5984-17.7152l11.264-213.6064c2.048-38.656-9.5744-62.7712-36.352-75.9808a89.7024 89.7024 0 0 0-35.072-8.9088L404.277248 348.928a93.6448 93.6448 0 0 0-33.792 6.912l-4.7104 2.0992c-25.4976 12.5952-37.1712 34.9696-36.608 70.2976l11.4688 216.832a22.1696 22.1696 0 0 1-8.6016 18.7904L136.450048 784.5376a22.4768 22.4768 0 0 1-30.0544-6.2976 22.272 22.272 0 0 1 4.6592-30.3104l184.32-113.7152-10.5472-198.0416C282.062848 382.0032 301.774848 341.9136 341.762048 320.1536 363.112448 309.504 381.493248 304.9472 400.539648 304.384h208.128c18.944 0.512 37.2224 5.12 54.272 13.568 41.2672 20.2752 62.5152 59.0336 61.44 111.9744l-10.752 204.288L896.053248 746.496a22.272 22.272 0 0 1 8.448 28.5184c-5.2224 8.8064-12.288 12.8-20.1728 12.8" fill="#e6e6e6" p-id="1503"></path><path d="M233.013248 939.7248a80.3328 80.3328 0 0 1-79.9232-80.4352c0-37.0688 15.0016-59.136 59.4944-87.5008l5.2736-3.328 152.576-87.7056-7.68-235.264a22.1696 22.1696 0 0 1 19.3024-22.784h0.512c13.824 0 23.1424 8.2432 24.576 19.0976l8.2944 250.9312a22.3744 22.3744 0 0 1-9.1136 18.7392L240.693248 806.8096c-34.9696 21.6064-43.008 31.3856-43.008 52.4288a35.7376 35.7376 0 0 0 31.8976 35.6864l128.512 0.2048-0.8192-5.888c-6.144-40.9088 11.4176-71.68 49.3568-86.6304 13.1072-5.12 26.9312-8.0384 40.96-8.704l132.9152-0.0512a22.3232 22.3232 0 0 1 2.304 44.4928l-131.9424 0.1024-7.8848 0.7168c-7.168 0.9216-14.08 2.6624-20.0192 4.9664-20.6336 8.1408-26.7264 22.6816-19.968 47.2576l1.024 3.7376h371.968a35.6352 35.6352 0 0 0 35.328-35.84c0-19.3536-7.168-29.3376-33.28-46.3872l-8.704-5.5296-164.5056-94.6176a22.4256 22.4256 0 0 1-11.1616-17.6128l8.0384-251.0336a22.2208 22.2208 0 0 1 22.272-21.6064c12.2368 0.3584 21.504 9.3184 22.3232 20.736l-7.68 237.5168 153.5488 88.32c46.3872 28.6208 62.464 50.2784 63.744 85.6576 0.1024 47.4112-33.28 82.688-75.776 84.8896l-4.1472 0.1024H233.013248z" fill="#e6e6e6" p-id="1504"></path></svg>`
    const logoSvg64 = `<svg t="1709112045300" class="relax4while_--icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1501" xmlns:xlink="http://www.w3.org/1999/xlink" width="64" height="64"><path d="M504.526848 95.7952C465.666048 95.7952 434.024448 127.488 434.024448 166.2976c0 38.912 31.6416 70.5024 70.5024 70.5024s70.5024-31.6416 70.5024-70.5024S543.387648 95.7952 504.526848 95.7952m0 185.6A115.2 115.2 0 0 1 389.378048 166.2976 115.3024 115.3024 0 0 1 504.526848 51.2a115.3024 115.3024 0 0 1 115.1488 115.2 115.2 115.2 0 0 1-115.1488 115.0464" fill="#e6e6e6" p-id="1502"></path><path d="M884.277248 787.8144a22.1184 22.1184 0 0 1-9.5232-2.1504L678.965248 665.2416a22.4256 22.4256 0 0 1-10.5984-17.7152l11.264-213.6064c2.048-38.656-9.5744-62.7712-36.352-75.9808a89.7024 89.7024 0 0 0-35.072-8.9088L404.277248 348.928a93.6448 93.6448 0 0 0-33.792 6.912l-4.7104 2.0992c-25.4976 12.5952-37.1712 34.9696-36.608 70.2976l11.4688 216.832a22.1696 22.1696 0 0 1-8.6016 18.7904L136.450048 784.5376a22.4768 22.4768 0 0 1-30.0544-6.2976 22.272 22.272 0 0 1 4.6592-30.3104l184.32-113.7152-10.5472-198.0416C282.062848 382.0032 301.774848 341.9136 341.762048 320.1536 363.112448 309.504 381.493248 304.9472 400.539648 304.384h208.128c18.944 0.512 37.2224 5.12 54.272 13.568 41.2672 20.2752 62.5152 59.0336 61.44 111.9744l-10.752 204.288L896.053248 746.496a22.272 22.272 0 0 1 8.448 28.5184c-5.2224 8.8064-12.288 12.8-20.1728 12.8" fill="#e6e6e6" p-id="1503"></path><path d="M233.013248 939.7248a80.3328 80.3328 0 0 1-79.9232-80.4352c0-37.0688 15.0016-59.136 59.4944-87.5008l5.2736-3.328 152.576-87.7056-7.68-235.264a22.1696 22.1696 0 0 1 19.3024-22.784h0.512c13.824 0 23.1424 8.2432 24.576 19.0976l8.2944 250.9312a22.3744 22.3744 0 0 1-9.1136 18.7392L240.693248 806.8096c-34.9696 21.6064-43.008 31.3856-43.008 52.4288a35.7376 35.7376 0 0 0 31.8976 35.6864l128.512 0.2048-0.8192-5.888c-6.144-40.9088 11.4176-71.68 49.3568-86.6304 13.1072-5.12 26.9312-8.0384 40.96-8.704l132.9152-0.0512a22.3232 22.3232 0 0 1 2.304 44.4928l-131.9424 0.1024-7.8848 0.7168c-7.168 0.9216-14.08 2.6624-20.0192 4.9664-20.6336 8.1408-26.7264 22.6816-19.968 47.2576l1.024 3.7376h371.968a35.6352 35.6352 0 0 0 35.328-35.84c0-19.3536-7.168-29.3376-33.28-46.3872l-8.704-5.5296-164.5056-94.6176a22.4256 22.4256 0 0 1-11.1616-17.6128l8.0384-251.0336a22.2208 22.2208 0 0 1 22.272-21.6064c12.2368 0.3584 21.504 9.3184 22.3232 20.736l-7.68 237.5168 153.5488 88.32c46.3872 28.6208 62.464 50.2784 63.744 85.6576 0.1024 47.4112-33.28 82.688-75.776 84.8896l-4.1472 0.1024H233.013248z" fill="#e6e6e6" p-id="1504"></path></svg>`
    const logoSvg32 = `<svg t="1709112045300" class="relax4while_--icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1501" xmlns:xlink="http://www.w3.org/1999/xlink" width="32" height="32"><path d="M504.526848 95.7952C465.666048 95.7952 434.024448 127.488 434.024448 166.2976c0 38.912 31.6416 70.5024 70.5024 70.5024s70.5024-31.6416 70.5024-70.5024S543.387648 95.7952 504.526848 95.7952m0 185.6A115.2 115.2 0 0 1 389.378048 166.2976 115.3024 115.3024 0 0 1 504.526848 51.2a115.3024 115.3024 0 0 1 115.1488 115.2 115.2 115.2 0 0 1-115.1488 115.0464" fill="#e6e6e6" p-id="1502"></path><path d="M884.277248 787.8144a22.1184 22.1184 0 0 1-9.5232-2.1504L678.965248 665.2416a22.4256 22.4256 0 0 1-10.5984-17.7152l11.264-213.6064c2.048-38.656-9.5744-62.7712-36.352-75.9808a89.7024 89.7024 0 0 0-35.072-8.9088L404.277248 348.928a93.6448 93.6448 0 0 0-33.792 6.912l-4.7104 2.0992c-25.4976 12.5952-37.1712 34.9696-36.608 70.2976l11.4688 216.832a22.1696 22.1696 0 0 1-8.6016 18.7904L136.450048 784.5376a22.4768 22.4768 0 0 1-30.0544-6.2976 22.272 22.272 0 0 1 4.6592-30.3104l184.32-113.7152-10.5472-198.0416C282.062848 382.0032 301.774848 341.9136 341.762048 320.1536 363.112448 309.504 381.493248 304.9472 400.539648 304.384h208.128c18.944 0.512 37.2224 5.12 54.272 13.568 41.2672 20.2752 62.5152 59.0336 61.44 111.9744l-10.752 204.288L896.053248 746.496a22.272 22.272 0 0 1 8.448 28.5184c-5.2224 8.8064-12.288 12.8-20.1728 12.8" fill="#e6e6e6" p-id="1503"></path><path d="M233.013248 939.7248a80.3328 80.3328 0 0 1-79.9232-80.4352c0-37.0688 15.0016-59.136 59.4944-87.5008l5.2736-3.328 152.576-87.7056-7.68-235.264a22.1696 22.1696 0 0 1 19.3024-22.784h0.512c13.824 0 23.1424 8.2432 24.576 19.0976l8.2944 250.9312a22.3744 22.3744 0 0 1-9.1136 18.7392L240.693248 806.8096c-34.9696 21.6064-43.008 31.3856-43.008 52.4288a35.7376 35.7376 0 0 0 31.8976 35.6864l128.512 0.2048-0.8192-5.888c-6.144-40.9088 11.4176-71.68 49.3568-86.6304 13.1072-5.12 26.9312-8.0384 40.96-8.704l132.9152-0.0512a22.3232 22.3232 0 0 1 2.304 44.4928l-131.9424 0.1024-7.8848 0.7168c-7.168 0.9216-14.08 2.6624-20.0192 4.9664-20.6336 8.1408-26.7264 22.6816-19.968 47.2576l1.024 3.7376h371.968a35.6352 35.6352 0 0 0 35.328-35.84c0-19.3536-7.168-29.3376-33.28-46.3872l-8.704-5.5296-164.5056-94.6176a22.4256 22.4256 0 0 1-11.1616-17.6128l8.0384-251.0336a22.2208 22.2208 0 0 1 22.272-21.6064c12.2368 0.3584 21.504 9.3184 22.3232 20.736l-7.68 237.5168 153.5488 88.32c46.3872 28.6208 62.464 50.2784 63.744 85.6576 0.1024 47.4112-33.28 82.688-75.776 84.8896l-4.1472 0.1024H233.013248z" fill="#e6e6e6" p-id="1504"></path></svg>`

    let displayFuncWithCorner = () => {
        // console.log('[relax4while] display with corner')
        let spanClassName = 'relax4while_--tips-corner'
        if (document.querySelector('div[class^="relax4while_--tips"]')) { return false; }

        let spanEle0 = document.createElement('div'),
            spanEle1 = document.createElement('div'),
            spanEle2 = document.createElement('div'),
            spanEle3 = document.createElement('div'),
            eles = [spanEle0, spanEle1, spanEle2, spanEle3],
            handler = function () { for (let i = 0; i < eles.length; i++) { eles[i].remove(); } }

        for (let i = 0; i < eles.length; i++) {
            eles[i].innerHTML = logoSvg32
            eles[i].setAttribute('class', `${spanClassName} relax4while_tips-corner-item-${i}`)
            eles[i].onclick = handler

            document.body.appendChild(eles[i])
        }
    },
        displayFuncWithModal = async () => {
            // console.log('[relax4while] display with modal')
            let spanClassName = 'relax4while_--tips-modal'
            if (document.querySelector('div[class^="relax4while_--tips"]')) { return false; }
            let mask = document.createElement('div'), logoBox = document.createElement('div')
            mask.setAttribute('class', spanClassName)
            logoBox.innerHTML = logoSvg128
            logoBox.onclick = () => { let eles = document.getElementsByClassName(spanClassName); eles[0].remove() }

            mask.appendChild(logoBox)

            document.body.appendChild(mask)
        },
        displayFuncWithGradient = async () => {
            // console.log('[relax4while] display with gradient')
            let spanClassName = 'relax4while_--tips-gradient'
            if (document.querySelector('div[class^="relax4while_--tips"]')) { return false; }

            let stage = document.createElement('div'), logoBox = document.createElement('div'), bodyClassName = document.body.getAttribute('class') ? document.body.getAttribute('class') : ''
            stage.setAttribute('class', spanClassName)
            logoBox.innerHTML = logoSvg128
            logoBox.onclick = async () => {
                let eles = document.getElementsByClassName(spanClassName);
                document.body.setAttribute('class', bodyClassName);
                eles[0].remove();
            }
            stage.appendChild(logoBox)

            document.body.setAttribute('class', bodyClassName + ' ' + spanClassName + '-body')
            document.body.appendChild(stage)
        },
        displayFuncWithWave = async () => {
            // console.log('[relax4while] display with wave')
            const Html_waves = `
                <div class="relax4while_header">

                <!--Content before waves-->
                <div class="relax4while_inner-header relax4while_flex">
                <!--the logo-->
                <div class="relax4while_logoBox" style="cursor: pointer;">`
                + logoSvg128 +
                `</div>
                <!--<h1>Relax for while</h1>-->
                </div>

                <!--Waves Container-->
                <div>
                <svg class="relax4while_waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                viewBox="0 24 150 28" preserveAspectRatio="none" shape-rendering="auto">
                <defs>
                <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z" />
                </defs>
                <g class="relax4while_parallax">
                <use xlink:href="#gentle-wave" x="48" y="0" fill="rgba(255,255,255,0.7" />
                <use xlink:href="#gentle-wave" x="48" y="3" fill="rgba(255,255,255,0.5)" />
                <use xlink:href="#gentle-wave" x="48" y="5" fill="rgba(255,255,255,0.3)" />
                <use xlink:href="#gentle-wave" x="48" y="7" fill="#fff" />
                </g>
                </svg>
                </div>
                <!--Waves end-->

                </div>
                <!--Header ends-->

                <!--Content starts-->
                <div class="relax4while_content flex">
                <!--<p></p>-->
                </div>
                <div style="height: 5vh;background-color: #fff;"></div>
                <!--Content ends-->`

            let spanClassName = 'relax4while_--tips-wave'
            if (document.querySelector('div[class^="relax4while_--tips"]')) { return false; }

            let stage = document.createElement('div'), bodyClassName = document.body.getAttribute('class') ? document.body.getAttribute('class') : ''
            stage.setAttribute('class', spanClassName)
            stage.innerHTML = Html_waves
            let handler = () => {
                let eles = document.getElementsByClassName(spanClassName);
                document.body.setAttribute('class', bodyClassName);
                eles[0].remove();
            }

            document.body.setAttribute('class', bodyClassName + ' ' + spanClassName + '-body')
            document.body.appendChild(stage)
            document.getElementsByClassName('relax4while_logoBox')[0].addEventListener('click', handler, false)
        }
    let callFuncs = [
        displayFuncWithCorner,
        displayFuncWithModal,
        displayFuncWithGradient,
        displayFuncWithWave
    ], callFuncIndex = settings.displayType !== -1 ? settings.displayType : Math.floor(Math.random() * callFuncs.length)
    console.log('[relax4while] callFuncsIndex: ', callFuncIndex)
    callFuncs[callFuncIndex]()
    // let text = `[${new Date().toLocaleString()}] relax4while fire notify action with: ${callFuncs[callFuncIndex].name.replace('displayFuncWith', '')}`
    //TODO write log...
}