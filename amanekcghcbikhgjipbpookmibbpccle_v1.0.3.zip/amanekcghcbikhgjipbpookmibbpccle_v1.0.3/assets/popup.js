/* ====== Popup Timer Logic ====== */
const STORAGE_KEY = 'relax4while_settings';
const ALARM_KEY = 'relax4while_alarm';
const BADGE_KEY = 'relax4while_badge'; // for badge countdown sync

const DISPLAY_TYPES = [
  { label: '角标', value: 0 },
  { label: '模态框', value: 1 },
  { label: '渐变', value: 2 },
  { label: '水波纹', value: 3 },
];

// DOM refs
const dialSvg = document.getElementById('dialSvg');
const handleEl = document.getElementById('dialHandle');
const progressArc = document.getElementById('progressArc');
const centerValue = document.getElementById('centerValue');
const inputMinutes = document.getElementById('inputMinutes');
const selectDisplay = document.getElementById('selectDisplay');
const btnStart = document.getElementById('btnStart');
const btnLabel = document.getElementById('btnLabel');
const btnPause = document.getElementById('btnPause');
const btnPauseLabel = document.getElementById('btnPauseLabel');

// State
let minutes = 1;
let isRunning = false;
let isPaused = false;
let countdownInterval = null;
let remainingSeconds = 0;

// Constants for dial geometry
const CX = 120, CY = 120, R = 95;
const MIN_MINUTES = 1, MAX_MINUTES = 60;

// =====================
// Initialization
// =====================
function init() {
  DISPLAY_TYPES.forEach(dt => {
    const opt = document.createElement('option');
    opt.value = dt.value;
    opt.textContent = dt.label;
    selectDisplay.appendChild(opt);
  });
  selectDisplay.value = 3;

  loadSettings();

  setupDialDrag();
  inputMinutes.addEventListener('input', onInputChange);
  inputMinutes.addEventListener('blur', onInputBlur);
  btnStart.addEventListener('click', toggleTimer);
  btnPause.addEventListener('click', togglePause);
  selectDisplay.addEventListener('change', saveSettings);

  updateDial(minutes);
}

// =====================
// Dial Drawing
// =====================
function minutesToAngle(m) {
  return (m / 60) * 360;
}

function angleToMinutes(deg) {
  let d = ((deg % 360) + 360) % 360;
  let m = Math.round((d / 360) * 60);
  if (m < MIN_MINUTES) m = MIN_MINUTES;
  if (m > MAX_MINUTES) m = MAX_MINUTES;
  return m;
}

function polarToCartesian(cx, cy, r, angleDeg) {
  const angleRad = ((angleDeg - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(angleRad),
    y: cy + r * Math.sin(angleRad),
  };
}

function describeArc(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 0 ${end.x} ${end.y}`;
}

function updateDial(m) {
  minutes = m;
  const angle = minutesToAngle(m);

  if (angle <= 0.1) {
    progressArc.setAttribute('d', '');
  } else if (angle >= 359.9) {
    const d1 = describeArc(CX, CY, R, 0, 180);
    const d2 = describeArc(CX, CY, R, 180, 359.99);
    progressArc.setAttribute('d', d1 + ' ' + d2);
  } else {
    progressArc.setAttribute('d', describeArc(CX, CY, R, 0, angle));
  }

  const handlePos = polarToCartesian(CX, CY, R, angle);
  handleEl.setAttribute('cx', handlePos.x);
  handleEl.setAttribute('cy', handlePos.y);

  centerValue.textContent = m;
  inputMinutes.value = m;
}

// =====================
// Dial Drag
// =====================
function setupDialDrag() {
  let dragging = false;

  const getAngleFromEvent = (e) => {
    const rect = dialSvg.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let clientX, clientY;
    if (e.touches) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    const dx = clientX - cx;
    const dy = clientY - cy;
    let angle = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
    if (angle < 0) angle += 360;
    return angle;
  };

  const onMove = (e) => {
    if (!dragging || isRunning) return;
    e.preventDefault();
    const angle = getAngleFromEvent(e);
    const m = angleToMinutes(angle);
    updateDial(m);
  };

  const onEnd = () => {
    if (!dragging) return;
    dragging = false;
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onEnd);
    document.removeEventListener('touchmove', onMove);
    document.removeEventListener('touchend', onEnd);
    saveSettings();
  };

  const onStart = (e) => {
    if (isRunning) return;
    e.preventDefault();
    dragging = true;
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
  };

  handleEl.addEventListener('mousedown', onStart);
  handleEl.addEventListener('touchstart', onStart, { passive: false });

  dialSvg.addEventListener('click', (e) => {
    if (isRunning) return;
    const angle = getAngleFromEvent(e);
    const m = angleToMinutes(angle);
    updateDial(m);
    saveSettings();
  });
}

// =====================
// Input sync
// =====================
function onInputChange() {
  if (isRunning) return;
  let val = parseInt(inputMinutes.value, 10);
  if (isNaN(val)) return;
  if (val < MIN_MINUTES) val = MIN_MINUTES;
  if (val > MAX_MINUTES) val = MAX_MINUTES;
  updateDial(val);
}

function onInputBlur() {
  let val = parseInt(inputMinutes.value, 10);
  if (isNaN(val) || val < MIN_MINUTES) val = MIN_MINUTES;
  if (val > MAX_MINUTES) val = MAX_MINUTES;
  updateDial(val);
  saveSettings();
}

// =====================
// Timer Control
// =====================
function toggleTimer() {
  if (isRunning) {
    stopTimer();
  } else {
    startTimer();
  }
}

function startTimer() {
  isRunning = true;
  isPaused = false;
  remainingSeconds = minutes * 60;

  const settings = {
    state: true,
    interval: minutes,
    displayType: parseInt(selectDisplay.value, 10),
  };
  chrome.storage.local.set({ [STORAGE_KEY]: JSON.stringify(settings) });

  // Directly create alarm from popup (don't rely on background indirect path)
  chrome.alarms.clear(ALARM_KEY).then(() => {
    chrome.alarms.create(ALARM_KEY, {
      delayInMinutes: minutes,
      periodInMinutes: minutes,
    });
  });

  // Store countdown end time for badge sync
  const endTime = Date.now() + remainingSeconds * 1000;
  chrome.storage.local.set({ [BADGE_KEY]: JSON.stringify({ endTime, paused: false, remaining: remainingSeconds }) });

  setRunningUI();
  updateCountdownDisplay();
  startInterval();
}

function startInterval() {
  countdownInterval = setInterval(() => {
    remainingSeconds--;
    updateCountdownDisplay();
    // Sync badge every 5 seconds to save writes
    if (remainingSeconds % 5 === 0 || remainingSeconds <= 10) {
      chrome.storage.local.set({ [BADGE_KEY]: JSON.stringify({ endTime: Date.now() + remainingSeconds * 1000, paused: false, remaining: remainingSeconds }) });
    }
    if (remainingSeconds <= 0) {
      // Timer naturally finished — do NOT clear alarm/state
      // Let background.js alarm fire and trigger the display effect
      onTimerFinished();
    }
  }, 1000);
}

// Called when countdown reaches 0 naturally — trigger display then loop
function onTimerFinished() {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }

  // Directly tell background.js to fire the display NOW
  chrome.runtime.sendMessage({ action: 'fireDisplay' });

  // Auto-restart countdown with same settings (loop mode)
  remainingSeconds = minutes * 60;
  const endTime = Date.now() + remainingSeconds * 1000;
  chrome.storage.local.set({ [BADGE_KEY]: JSON.stringify({ endTime, paused: false, remaining: remainingSeconds }) });

  updateCountdownDisplay();
  startInterval();
}

// Called when user manually clicks stop
function stopTimer() {
  isRunning = false;
  isPaused = false;
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }

  // Directly clear alarm
  chrome.alarms.clear(ALARM_KEY);

  // Turn off alarm — user explicitly stopped
  const settings = {
    state: false,
    interval: minutes,
    displayType: parseInt(selectDisplay.value, 10),
  };
  chrome.storage.local.set({ [STORAGE_KEY]: JSON.stringify(settings) });
  // Clear badge data
  chrome.storage.local.set({ [BADGE_KEY]: JSON.stringify({ endTime: 0, paused: false, remaining: 0 }) });

  setIdleUI();
  updateDial(minutes);
}

// =====================
// Pause / Resume
// =====================
function togglePause() {
  if (isPaused) {
    resumeTimer();
  } else {
    pauseTimer();
  }
}

function pauseTimer() {
  isPaused = true;
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }
  btnPause.classList.add('paused');
  btnPauseLabel.textContent = '▶ 继续';

  // Pause the alarm too
  chrome.alarms.clear(ALARM_KEY);
  // Badge: store paused state
  chrome.storage.local.set({ [BADGE_KEY]: JSON.stringify({ endTime: 0, paused: true, remaining: remainingSeconds }) });
}

function resumeTimer() {
  isPaused = false;
  btnPause.classList.remove('paused');
  btnPauseLabel.textContent = '⏸ 暂停';

  // Re-create alarm with remaining time
  const remainingMinutes = remainingSeconds / 60;
  const settings = {
    state: true,
    interval: remainingMinutes > 0 ? remainingMinutes : minutes,
    displayType: parseInt(selectDisplay.value, 10),
  };
  chrome.storage.local.set({ [STORAGE_KEY]: JSON.stringify(settings) });
  chrome.alarms.create(ALARM_KEY, { delayInMinutes: remainingMinutes > 0 ? remainingMinutes : minutes });

  // Badge: resume
  const endTime = Date.now() + remainingSeconds * 1000;
  chrome.storage.local.set({ [BADGE_KEY]: JSON.stringify({ endTime, paused: false, remaining: remainingSeconds }) });

  startInterval();
}

// =====================
// UI State Helpers
// =====================
function setRunningUI() {
  btnStart.classList.add('running');
  btnLabel.innerHTML = '⏹ 停止';
  btnPause.style.display = 'block';
  btnPause.classList.remove('paused');
  btnPauseLabel.textContent = '⏸ 暂停';
  inputMinutes.disabled = true;
  selectDisplay.disabled = true;
}

function setIdleUI() {
  btnStart.classList.remove('running');
  btnLabel.innerHTML = '▶ 开始计时';
  btnPause.style.display = 'none';
  btnPause.classList.remove('paused');
  inputMinutes.disabled = false;
  selectDisplay.disabled = false;
}

function updateCountdownDisplay() {
  const m = Math.floor(remainingSeconds / 60);
  const s = remainingSeconds % 60;
  const mStr = String(m).padStart(2, '0');
  const sStr = String(s).padStart(2, '0');

  // Update center value to show countdown
  centerValue.textContent = `${mStr}:${sStr}`;
}

// =====================
// Settings persistence
// =====================
function saveSettings() {
  const settings = {
    state: isRunning,
    interval: minutes,
    displayType: parseInt(selectDisplay.value, 10),
  };
  chrome.storage.local.set({ [STORAGE_KEY]: JSON.stringify(settings) });
}

async function loadSettings() {
  try {
    const result = await chrome.storage.local.get([STORAGE_KEY, BADGE_KEY]);
    if (result && result[STORAGE_KEY]) {
      const settings = JSON.parse(result[STORAGE_KEY]);
      if (settings.interval && settings.interval >= MIN_MINUTES && settings.interval <= MAX_MINUTES) {
        minutes = Math.round(settings.interval);
      }
      if (settings.displayType !== undefined) {
        selectDisplay.value = settings.displayType;
      }
      updateDial(minutes);

      // Restore running state from badge data
      if (result[BADGE_KEY]) {
        const badge = JSON.parse(result[BADGE_KEY]);
        if (badge.paused && badge.remaining > 0) {
          // Was paused
          isRunning = true;
          isPaused = true;
          remainingSeconds = badge.remaining;
          setRunningUI();
          btnPause.classList.add('paused');
          btnPauseLabel.textContent = '▶ 继续';
          updateCountdownDisplay();
          return;
        }
        if (badge.endTime > 0 && !badge.paused) {
          const now = Date.now();
          const remaining = Math.max(0, Math.ceil((badge.endTime - now) / 1000));
          if (remaining > 0) {
            isRunning = true;
            isPaused = false;
            remainingSeconds = remaining;
            setRunningUI();
            updateCountdownDisplay();
            startInterval();
            return;
          }
        }
      }

      // Badge expired but state is still on → alarm is still cycling in background
      // Query actual alarm to restore countdown for current cycle
      if (settings.state) {
        try {
          const alarm = await chrome.alarms.get(ALARM_KEY);
          if (alarm) {
            const now = Date.now();
            const remaining = Math.max(0, Math.ceil((alarm.scheduledTime - now) / 1000));
            if (remaining > 0) {
              isRunning = true;
              isPaused = false;
              remainingSeconds = remaining;
              // Sync badge with actual alarm time
              chrome.storage.local.set({
                [BADGE_KEY]: JSON.stringify({
                  endTime: alarm.scheduledTime,
                  paused: false,
                  remaining: remaining
                })
              });
              setRunningUI();
              updateCountdownDisplay();
              startInterval();
              return;
            } else {
              // Alarm exists but scheduledTime already passed, next cycle coming
              // Reset to full interval and restart
              isRunning = true;
              isPaused = false;
              remainingSeconds = minutes * 60;
              const endTime = Date.now() + remainingSeconds * 1000;
              chrome.storage.local.set({
                [BADGE_KEY]: JSON.stringify({
                  endTime,
                  paused: false,
                  remaining: remainingSeconds
                })
              });
              setRunningUI();
              updateCountdownDisplay();
              startInterval();
              return;
            }
          }
        } catch (alarmErr) {
          console.log('[popup] alarm query failed:', alarmErr);
        }
      }
    }
  } catch (e) {
    console.log('[popup] loadSettings failed:', e);
  }
}

// =====================
// Boot
// =====================
document.addEventListener('DOMContentLoaded', init);
